function getTime() {
    var data = new Date();
    var godziny = data.getHours();
    var minuty = data.getMinutes();
    var sekundy = data.getSeconds();
    var napis = godziny + ":" + minuty + ":" + sekundy;

    document.getElementById("zegar").innerHTML = napis;
    setInterval(getTime, 1000);
}